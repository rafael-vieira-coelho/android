package android.com.layouts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {//}, View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) //aqui definimos qual atividade será usada

    }

    fun loadLinearLayout(v: View) {
        setContentView(R.layout.activity_main)
    }


    fun loadTableLayout(v: View) {
        setContentView(R.layout.my_table_layout)
    }

    fun loadConstrantLayout(v: View) {
        setContentView(R.layout.my_constrant_layout)
    }
/*
    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.button1 -> {
                loadTableLayout(view);
            }
            R.id.button2 -> {
                loadConstrantLayout(view);
            }
        }
    }

 */
}